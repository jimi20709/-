import SwiftUI  // 導入 SwiftUI 框架，用於構建 UI

// MARK: - 井字棋遊戲邏輯
/// 這個結構體 (`struct`) 負責處理遊戲的核心邏輯，例如落子、切換玩家和判斷勝負。
struct TicTacToeGame {
    /// 3x3 棋盤，每個格子可能是 "X"、"O" 或 ""（空）
    var board: [[String]] = Array(repeating: Array(repeating: "", count: 3), count: 3)
    
    /// 當前玩家，遊戲從 "X" 開始
    var currentPlayer: String = "X"
    
    /// 嘗試在指定位置落子
    /// - Parameters:
    ///   - row: 棋盤的行索引（0~2）
    ///   - col: 棋盤的列索引（0~2）
    /// - Returns: 成功落子返回 `true`，否則返回 `false`
    mutating func makeMove(row: Int, col: Int) -> Bool {
        if board[row][col] == "" { // 確保該位置是空的
            board[row][col] = currentPlayer
            return true
        }
        return false
    }
    
    /// 切換當前玩家，"X" 變成 "O"，"O" 變成 "X"
    mutating func switchPlayer() {
        currentPlayer = (currentPlayer == "X") ? "O" : "X"
    }
    
    /// 檢查是否有玩家獲勝
    /// - Returns: 若有勝者，回傳 "X" 或 "O"，否則回傳 `nil`
    func checkWinner() -> String? {
        // 檢查行
        for i in 0..<3 {
            if board[i][0] != "", board[i][0] == board[i][1], board[i][1] == board[i][2] {
                return board[i][0]
            }
        }
        
        // 檢查列
        for j in 0..<3 {
            if board[0][j] != "", board[0][j] == board[1][j], board[1][j] == board[2][j] {
                return board[0][j]
            }
        }
        
        // 檢查對角線
        if board[0][0] != "", board[0][0] == board[1][1], board[1][1] == board[2][2] {
            return board[0][0]
        }
        
        if board[0][2] != "", board[0][2] == board[1][1], board[1][1] == board[2][0] {
            return board[0][2]
        }
        
        return nil // 沒有勝者
    }
    
    /// 檢查是否平局（棋盤已滿且沒有勝者）
    /// - Returns: 如果棋盤已滿，回傳 `true`，否則回傳 `false`
    func isBoardFull() -> Bool {
        return !board.joined().contains("") // 檢查是否還有空格
    }
    
    /// 重置遊戲，清空棋盤並讓 "X" 先開始
    mutating func resetGame() {
        board = Array(repeating: Array(repeating: "", count: 3), count: 3)
        currentPlayer = "X"
    }
}

// MARK: - 井字棋 UI（SwiftUI）
struct ContentView: View {
    @State private var game = TicTacToeGame()  // 遊戲邏輯的狀態
    @State private var showAlert = false      // 是否顯示勝負提示
    @State private var alertMessage = ""      // 提示框的訊息
    
    var body: some View {
        //加入背景（重命名照片如1234.jpg)
        ZStack { Image("1234.jpg")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            VStack {
                // 顯示當前玩家
                Text("當前玩家: \(game.currentPlayer)")
                    .font(.title)
                    .padding()
                
                // 棋盤 UI，使用 VStack + HStack 組成 3x3 格子
                VStack(spacing: 5) {
                    ForEach(0..<3, id: \.self) { row in
                        HStack(spacing: 5) {
                            ForEach(0..<3, id: \.self) { col in
                                Button(action: {
                                    handleMove(row: row, col: col)
                                }) {
                                    Text(game.board[row][col])
                                        .font(.largeTitle)
                                        .frame(width: 80, height: 80)
                                        .background(Color.gray.opacity(0.3))
                                        .foregroundColor(.black)
                                        .cornerRadius(10)
                                }
                            }
                        }
                    }
                }
                .padding()
                
                // "重新開始" 按鈕
                Button("重新開始") {
                    game.resetGame()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            // 顯示勝利或平局彈窗
            .alert(isPresented: $showAlert) {
                Alert(title: Text(alertMessage), dismissButton: .default(Text("確定")) {
                    game.resetGame() // 點擊確定後重置遊戲
                })
            }
        }
    }
    
    /// 處理玩家的落子操作
    /// - Parameters:
    ///   - row: 行索引
    ///   - col: 列索引
    private func handleMove(row: Int, col: Int) {
        // 嘗試落子，若成功則繼續
        if game.makeMove(row: row, col: col) {
            // 檢查是否有勝者
            if let winner = game.checkWinner() {
                alertMessage = "\(winner) 贏了！"
                showAlert = true
                return
            }
            
            // 檢查是否平局
            if game.isBoardFull() {
                alertMessage = "平局！"
                showAlert = true
                return
            }
            
            // 切換玩家
            game.switchPlayer()
        }
    }
}

// MARK: - Swift Playgrounds 入口（無需 `@main`，Playgrounds 會自動處理）
